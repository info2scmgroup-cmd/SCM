# SCM Group — Test Credentials

## Website Access
No authentication required — this is a public-facing corporate website.

## Test Data for Forms

### Contact Form
- Name: Test User
- Email: test@example.com
- Phone: +91 98765 43210
- Company: Test Company
- Service: IT Staffing
- Message: This is a test message

### Career Application
- Name: John Doe
- Email: johndoe@example.com
- Phone: +91 99999 88888
- Position: IT Staffing Consultant
- Experience: 3 years
- Message: I am interested in this role.

## Backend API
- Base URL: https://scm-it-agency.preview.emergentagent.com
- Health: GET /api/
- Contact submissions: GET /api/contact/submissions
- Career applications: GET /api/careers/applications
