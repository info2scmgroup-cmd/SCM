# SCM Group Management Services

**Official website for SCM Group Management Services** — a leading IT staffing and manpower agency based in Hyderabad, India.

🌐 **Live Website:** [https://scmgroup-services.com](https://scmgroup-services.com)

---

## About

SCM Group Management Services connects businesses with skilled talent across IT, Manufacturing, Construction, Facility Management, and more. Founded by **Chandramohan Sivala**, SCM Group has grown into a trusted workforce partner for clients across India.

📍 12-4-160, Pragathi Nagar, Moosapet, Kukatpally, Hyderabad 500018  
📞 +91 81435 97569  
📧 info@scmgroup-services.com | info2scmgroup@gmail.com  
🔗 [LinkedIn](https://www.linkedin.com/company/scm-group-services/)

---

## Pages

| Page | Description |
|------|-------------|
| Home | Hero, stats, services overview, partner network |
| About | Company story, mission, values, leadership team |
| Services | IT Staffing, Manpower Supply, HR Consulting, Payroll, etc. |
| Industries | IT, Manufacturing, Construction, Healthcare, Retail, and more |
| Careers | Job listings and application portal |
| Clients | Client marquee and partner network |
| Contact | Contact form, map, and business details |

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 19, Tailwind CSS, Framer Motion |
| SEO | react-helmet-async |
| Animations | Framer Motion |
| Icons | Lucide React |

The site is now a fully static frontend, deployed via GitHub Pages. The Contact and Careers "Apply" forms open the visitor's email app pre-filled with their details (`mailto:`) instead of calling a server.

An optional FastAPI + MongoDB backend (`/backend`) is included for reference if you ever want a server-backed contact form again, but it is **not used by the live site** and is not deployed.

---

## Project Structure

```
/
├── frontend/              # React frontend (this is what's deployed)
│   ├── src/
│   │   ├── components/    # Navbar, Footer, WhatsAppButton, SEO
│   │   ├── pages/         # HomePage, AboutPage, ServicesPage, etc.
│   │   └── hooks/
│   └── public/
│       └── CNAME          # custom domain for GitHub Pages
├── backend/                # optional FastAPI backend, not deployed
└── .github/workflows/
    └── deploy.yml          # builds frontend/ and deploys to GitHub Pages on every push to main
```

---

## Deploying (GitHub Pages)

1. Push this repo to GitHub.
2. In the repo, go to **Settings → Pages** and set **Source** to **GitHub Actions**.
3. Push to `main` — the included workflow (`.github/workflows/deploy.yml`) builds `frontend/` with Yarn and deploys `frontend/build` automatically.
4. In your domain registrar's DNS, point `scmgroup-services.com` at GitHub Pages (A records to `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`). The `frontend/public/CNAME` file keeps the custom domain set on every deploy.

## Running Locally

```bash
cd frontend
yarn install
yarn start
```

---

## Contact

For business enquiries: [info@scmgroup-services.com](mailto:info@scmgroup-services.com)
